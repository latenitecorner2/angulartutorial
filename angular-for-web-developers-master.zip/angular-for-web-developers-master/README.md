# angular-for-web-developers

Please find the source code for the TaskTracker Application

http://www.adeveloperdiary.com/angular-js/angular-1-x/the-best-way-to-master-angular-js-part-1/
